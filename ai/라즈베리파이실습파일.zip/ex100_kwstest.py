#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Example 1: GiGA Genie Keyword Spotting"""

from __future__ import print_function

import audioop
from ctypes import *
import RPi.GPIO as GPIO
import ktkws # KWS
import MicrophoneStream as MS
KWSID = ['기가지니', '지니야', '친구야', '자기야']
RATE = 16000
CHUNK = 512

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(29, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(31, GPIO.OUT)
btn_status = False

def callback(channel):  
	print("falling edge detected from pin {}".format(channel))
	global btn_status
	btn_status = True
	print(btn_status)

GPIO.add_event_detect(29, GPIO.FALLING, callback=callback, bouncetime=10)

ERROR_HANDLER_FUNC = CFUNCTYPE(None, c_char_p, c_int, c_char_p, c_int, c_char_p)
def py_error_handler(filename, line, function, err, fmt):
  dummy_var = 0
c_error_handler = ERROR_HANDLER_FUNC(py_error_handler)
asound = cdll.LoadLibrary('libasound.so')
asound.snd_lib_error_set_handler(c_error_handler)


def detect():
	# 마이크입력받아오는 함수 
	cnt = 0
	with MS.MicrophoneStream(RATE, CHUNK) as stream:
		audio_generator = stream.generator()

		for content in audio_generator:
			cnt += 1
			rc = ktkws.detect(content)# 마이크입력값과 #기가지니 키워드 정했다면 마이크로 '기가지니' 입력  같지 않으면 대기.   
			rms = audioop.rms(content,2)
			#print('audio rms = %d' % (rms))
			print('detect=>',rc, ":",cnt)
			if (rc == 1):
				MS.play_file("../data/sample_sound.wav")
				return 200
			elif (rc == 0 and cnt > 100): #1. 마이크입력값이 키워드 다른 경우 
				return 404

def btn_detect():
	global btn_status
	with MS.MicrophoneStream(RATE, CHUNK) as stream:
		audio_generator = stream.generator()

		for content in audio_generator:
			GPIO.output(31, GPIO.HIGH)
			rc = ktkws.detect(content)
			rms = audioop.rms(content,2)
			#print('audio rms = %d' % (rms))
			GPIO.output(31, GPIO.LOW)
			if (btn_status == True):
				rc = 1
				btn_status = False			
			if (rc == 1):
				GPIO.output(31, GPIO.HIGH)
				MS.play_file("../data/sample_sound.wav")
				return 200

def test(key_word = '기가지니'):
	rc = ktkws.init("../data/kwsmodel.pack")
	print ('init rc = %d' % (rc))
	rc = ktkws.start()
	print ('start rc = %d' % (rc))
	print ('\n호출어를 불러보세요~\n')
	#ktkws.set_keyword(KWSID.index(key_word))
	#키워
	for k in KWSID:
		if k == key_word:
			#print(k)
			ktkws.set_keyword(KWSID.index(key_word))
			rc = detect()#마이크입력 (200, 404)
			break
		else :
			rc = 404 #키워드세팅 잘못 
		
	print ('detect rc = %d' % (rc))
	if( rc == 200):
		print ('\n\n호출어가 정상적으로 인식되었습니다.\n\n')
	else :
		print ('\n\n호출어가 	비정상적으로 인식되었거나 없키워드가 목록에 습니다.\n\n')
	ktkws.stop()
	result_test(key_word , rc);#파일 기록  키워드 응답결과 
	return rc

def btn_test(key_word = '기가지니'):
	global btn_status
	rc = ktkws.init("../data/kwsmodel.pack")
	print ('init rc = %d' % (rc))
	rc = ktkws.start()
	print ('start rc = %d' % (rc))
	print ('\n버튼을 눌러보세요~\n')
	ktkws.set_keyword(KWSID.index(key_word))
	rc = btn_detect()
	print ('detect rc = %d' % (rc))
	print ('\n\n호출어가 정상적으로 인식되었습니다.\n\n')
	ktkws.stop()
	result_test(key_word, rc)
	return rc

def result_test(key_word, rc):
	import datetime as dt
	now = dt.datetime.now()
	now = now.strftime("%Y-%m-%d %H:%M:%S") # datetime타입을 문자열 변환 
	
	#test 호출시마다 시간,  키워드 단어,  응답 1줄로 result.txt 에 저장 
	#록현재시간 설정 
	#	result.txt 파일 open 

	file = open("result.txt", "a")   
	file.write(now + "," + key_word + "," + str(rc) + "\n")  
	file.close();


def main(): 

	#import ex1_kwstest as ex1
	#ex1.test()

	test()#기가지니 키워드 정했다면 마이크로 '기가지니' 입력 - 200 결과 세팅 . 기가지니 키워드 정했다면 마이크로 '멀티야'  입력  - '기가지니' 입력을 무한 대기 
	test('지니야')
	test('친구야')
	test('자기야')
	test('멀티야') #키워드(서버 키워드인식불가) - 404 결과 세팅 

if __name__ == '__main__':
	main()
